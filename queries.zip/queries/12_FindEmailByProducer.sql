-- 12. "Producer Contact Info: Look up producer email addresses by name."

SELECT pro_email
FROM PRODUCER
WHERE pro_name = 'Duff Farms';