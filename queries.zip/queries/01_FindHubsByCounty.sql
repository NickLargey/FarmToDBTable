-- Find hubs based on county

SELECT *
FROM HUB
WHERE hub_county = 'Cumberland'