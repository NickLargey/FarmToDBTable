-- Find producers based on county
SELECT *
FROM PRODUCER
WHERE pro_county = 'Cumberland'