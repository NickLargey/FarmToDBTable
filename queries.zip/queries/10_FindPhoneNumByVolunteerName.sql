-- 10. "Volunteer Directory: Retrieve volunteer phone numbers by name."

SELECT vol_phone
FROM VOLUNTEER
WHERE vol_name = 'Aimee Franklin';