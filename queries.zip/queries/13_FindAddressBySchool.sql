-- 13. "School Address Finder: Get the address of a school by its name"

SELECT sch_address
FROM SCHOOL
WHERE sch_name = 'Deering High School';