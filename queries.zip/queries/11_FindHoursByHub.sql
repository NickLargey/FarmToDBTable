-- 11.  "Hub Schedule Info: Access a hub's operating hours by its name."

SELECT hub_hours
FROM HUB
WHERE hub_name = 'Cumberland Hub';