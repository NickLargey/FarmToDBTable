-- find all volunteer roles at any given hub

SELECT r.*
FROM HUB_ROLE hr
JOIN ROLE r ON hr.role_id = r.role_id
JOIN HUB h ON hr.hub_id = h.hub_id
WHERE h.hub_id = <your_hub_id>;