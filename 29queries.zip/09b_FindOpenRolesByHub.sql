-- find all "open" volunteer roles at any given hub
-- all roles NOT in the volunteer_role table,
-- meaning the role hasn't been fulfilled yet

SELECT r.*
FROM HUB_ROLE hr
JOIN ROLE r ON hr.role_id = r.vrol_id
JOIN HUB h ON hr.hub_id = h.hub_id
LEFT JOIN VOLUNTEER_ROLE vr ON hr.vrol_id = vr.vrol_id
WHERE h.hub_id = <your_hub_id> AND vr.vrol_id IS NULL;