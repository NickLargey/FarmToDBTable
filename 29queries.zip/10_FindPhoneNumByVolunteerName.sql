-- Retrieve volunteer phone numbers by name.

SELECT vol_phone
FROM VOLUNTEER
WHERE vol_name = '<your_volunteer_name>';