-- Get the address of a school by its name

SELECT sch_address
FROM SCHOOL
WHERE sch_name = '<your_school_name>';