-- Look up producer email addresses by name.

SELECT pro_email
FROM PRODUCER
WHERE pro_name = '<your_producer_name>';