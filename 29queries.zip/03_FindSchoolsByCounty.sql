-- Find schools based on county
SELECT *
FROM SCHOOL
WHERE sch_county = '<your_county>';