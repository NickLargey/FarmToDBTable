-- Find purchase orders by the quantity of food ordered

SELECT po.*
FROM PURCHASE_ORDER po
JOIN FOOD_ITEM fi ON po.fi_id = fi.fi_id
WHERE po.pur_status = 3
  AND fi.fi_name = '<your_food_item_name>'
  AND fi.fi_unit = '<your_food_item_unit>'
  AND po.pur_quantity > <your_min_quantity>;